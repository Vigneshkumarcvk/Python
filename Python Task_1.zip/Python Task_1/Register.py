from tkinter import *

from tkinter import messagebox

import os
def register_user():
    username_info = username.get()
    password_info = password.get()
    file = open(username_info, "w")
    file.write(username_info + "\n")
    file.write(password_info)
    file.close()
    u_entry.delete(0, END)
    p_entry.delete(0, END)
    messagebox.showinfo("info", "Registration Successful")

def register():
    global username, password
    global u_entry, p_entry, root1
    root1 = Toplevel(root)
    username = StringVar()
    password = StringVar()
    root1.title("Register")
    root1.configure(bg="#F1C40F")
    w1 = 500
    h1 = 400
    root1.geometry("%dx%d+%d+%d" % (w1, h1, x, y))
    Label(root1, text="Please enter the details below\nin the given empty fields", font=("Georgia", 15),
          bg="#F9E79F").pack()
    Label(root1, text="", bg="#F1C40F").pack()
    Label(root1, text="Username *", font=("Arial", 12), bg="#F9E79F").pack()
    Label(root1, text="", bg="#F1C40F").pack()
    u_entry = Entry(root1, textvariable=username, width="12", borderwidth=3)
    u_entry.pack()
    Label(root1, text="", bg="#F1C40F").pack()
    Label(root1, text="Password *", font=("Arial", 12), bg="#F9E79F").pack()
    Label(root1, text="", bg="#F1C40F").pack()
    p_entry = Entry(root1, textvariable=password, width="12", borderwidth=3)
    p_entry.pack()
    Label(root1, text="", bg="#F1C40F").pack()
    button = Button(root1, text="Register", width=10, command=lambda: register_user(), bg="#F1C40F",
                    font=("Arial", 12)).pack()
    root1.mainloop()
