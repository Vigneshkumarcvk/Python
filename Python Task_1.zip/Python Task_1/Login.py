from tkinter import *

from tkinter import messagebox

import os
def login_verify():
    username1 = username_verify.get()
    password1 = password_verify.get()
    u_entry1.delete(0, END)
    p_entry1.delete(0, END)
    list_of_files = os.listdir()
    if username1 in list_of_files:
        file1 = open(username1, "r")
        verify = file1.read().splitlines()
        if password1 in verify:
            messagebox.showinfo("info", "Login Successfull!!")
        else:
            messagebox.showinfo("info", "Password has not been recognised")
    else:
        messagebox.showinfo("info", "User not found")

def login_verify():
    username1 = username_verify.get()
    password1 = password_verify.get()
    u_entry1.delete(0, END)
    p_entry1.delete(0, END)
    list_of_files = os.listdir()
    if username1 in list_of_files:
        file1 = open(username1, "r")
        verify = file1.read().splitlines()
        if password1 in verify:
            messagebox.showinfo("info", "Login Successfull!!")
        else:
            messagebox.showinfo("info", "Password has not been recognised")
    else:
        messagebox.showinfo("info", "User not found")
