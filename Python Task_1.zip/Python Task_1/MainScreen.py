from tkinter import *

from tkinter import messagebox

import os
def mainscreen():
    global root, screen_w, screen_h, x, y
    root = Tk()
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    w = 350
    h = 300
    x = screen_w / 4.5
    y = screen_h / 4.5
    root.geometry("%dx%d+%d+%d" % (w, h, x, y))
    root.title("Register-Login")
    root.configure(bg="#7472f2")
    heading = Label(root, text="Register/Login Form", font=("Georgia", 18), bg="#7472f2").pack()
    Label(root, text="", bg="#7472f2").pack()
    login_button = Button(root, text="Login", width="300", font=("Georgia", 15), bg="#7472f2",
                          command=lambda: login()).pack()
    Label(root, text="", bg="#7472f2").pack()
    register_button = Button(root, text="Register", width="300", font=("Georgia", 15), bg="#7472f2",
                             command=lambda: register()).pack()
    Label(root, text="", bg="#7472f2").pack()
    root.mainloop()


mainscreen()