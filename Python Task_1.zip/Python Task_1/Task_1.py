from tkinter import *

from tkinter import messagebox

import os


def register_user():
    username_info = username.get()
    password_info = password.get()
    file = open(username_info, "w")
    file.write(username_info + "\n")
    file.write(password_info)
    file.close()
    u_entry.delete(0, END)
    p_entry.delete(0, END)
    messagebox.showinfo("info", "Registration Successful")


def login_verify():
    username1 = username_verify.get()
    password1 = password_verify.get()
    u_entry1.delete(0, END)
    p_entry1.delete(0, END)
    list_of_files = os.listdir()
    if username1 in list_of_files:
        file1 = open(username1, "r")
        verify = file1.read().splitlines()
        if password1 in verify:
            messagebox.showinfo("info", "Login Successfull!!")
        else:
            messagebox.showinfo("info", "Password has not been recognised")
    else:
        messagebox.showinfo("info", "User not found")



def register():
    global username, password
    global u_entry, p_entry, root1
    root1 = Toplevel(root)
    username = StringVar()
    password = StringVar()
    root1.title("Register")
    root1.configure(bg="#F1C40F")
    w1 = 500
    h1 = 400
    root1.geometry("%dx%d+%d+%d" % (w1, h1, x, y))
    Label(root1, text="Please enter the details below\nin the given empty fields", font=("Georgia", 15),
          bg="#F9E79F").pack()
    Label(root1, text="", bg="#F1C40F").pack()
    Label(root1, text="Username *", font=("Arial", 12), bg="#F9E79F").pack()
    Label(root1, text="", bg="#F1C40F").pack()
    u_entry = Entry(root1, textvariable=username, width="12", borderwidth=3)
    u_entry.pack()
    Label(root1, text="", bg="#F1C40F").pack()
    Label(root1, text="Password *", font=("Arial", 12), bg="#F9E79F").pack()
    Label(root1, text="", bg="#F1C40F").pack()
    p_entry = Entry(root1, textvariable=password, width="12", borderwidth=3)
    p_entry.pack()
    Label(root1, text="", bg="#F1C40F").pack()
    button = Button(root1, text="Register", width=10, command=lambda: register_user(), bg="#F1C40F",
                    font=("Arial", 12)).pack()
    root1.mainloop()


def login():
    global root2, u_entry1, p_entry1
    global username_verify, password_verify
    username_verify = StringVar()
    password_verify = StringVar()
    root2 = Toplevel(root)
    w2 = 400
    h2 = 450
    root2.geometry("%dx%d+%d+%d" % (w2, h2, x, y))
    root2.configure(bg="#d5d9f0")
    root2.title("Login")
    Label(root2, text="Username", bg="#d5d9f0", font=("Arial", 17)).pack()
    Label(root2, text="", bg="#d5d9f0").pack()
    u_entry1 = Entry(root2, textvariable=username_verify, width=15, borderwidth=3)
    u_entry1.pack()
    Label(root2, text="", bg="#d5d9f0").pack()
    Label(root2, text="Password", bg="#d5d9f0", font=("Arial", 17)).pack()
    Label(root2, text="", bg="#d5d9f0").pack()
    p_entry1 = Entry(root2, textvariable=password_verify, width=15, borderwidth=3)
    p_entry1.pack()
    Label(root2, text="", bg="#d5d9f0").pack()
    button1 = Button(root2, text="Login", width=10, command=lambda: login_verify(), bg="#d5d9f0",
                     font=("Arial", 13)).pack()
    root2.mainloop()

def mainscreen():
    global root, screen_w, screen_h, x, y
    root = Tk()
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    w = 350
    h = 300
    x = screen_w / 4.5
    y = screen_h / 4.5
    root.geometry("%dx%d+%d+%d" % (w, h, x, y))
    root.title("Register-Login")
    root.configure(bg="#7472f2")
    heading = Label(root, text="Register/Login Form", font=("Arial", 18), bg="#7472f2").pack()
    Label(root, text="", bg="#7472f2").pack()
    login_button = Button(root, text="Login", width="300", font=("Arial", 15), bg="#7472f2",
                          command=lambda: login()).pack()
    Label(root, text="", bg="#7472f2").pack()
    register_button = Button(root, text="Register", width="300", font=("Arial", 15), bg="#7472f2",
                             command=lambda: register()).pack()
    Label(root, text="", bg="#7472f2").pack()
    root.mainloop()


mainscreen()

